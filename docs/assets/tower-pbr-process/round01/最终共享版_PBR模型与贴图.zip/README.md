# 防御塔最终共享版

asset.glb 为原实验导出模型，内含材质。textures/ 保存独立贴图。BaseColor 使用 sRGB，其余通道按线性数据解释，Normal 采用实验声明的 OpenGL 约定。

顶层贴图为 2048² mip0，mips/ 保存 mip1 至 mip11。ORM 的 R/G/B 分别为 AO/Roughness/Metallic。有效表面参数为 AO=1、Roughness=0.6、Metallic=0。三个灰度通道从烘焙 ORM 逐像素拆分。

模型为 7650 三角形、48 连通岛、24 独立图块。原记录数值状态为 DIAGNOSTIC，Agent 看图结论为 VISUAL_KEEP，人工和游戏 Shader 状态为 NOT_RUN。

[verified: round02/report/results.json; report/appearance_review.json; bake/texture/material_metadata.json; organized channel pixel checks]
