# ReSeam Skill完整安装包

将本目录交给Agent，发送下面这句话。`[opinion]`

> 安装这个ReSeam Skill包，并按全量安装合同安装所有依赖与工具。由你检测机器、获取锁定源码、安装配置全部可用组件、执行小型冒烟并修复可恢复问题。完成后给我逐项可用状态、日志与使用方式。

先读取 [包内全量安装合同](skills/reseam-uv/references/full-installation.md) 和
[依赖清单](skills/reseam-uv/references/install-manifest.json)，运行下面的Skill安装入口，
再继续执行合同中的全部环境安装步骤。`[opinion]`

[工具目录](TOOL-CATALOG.json) 保存打包时实际CLI返回的工具与参数说明。
目标机器安装后重新运行tools list/describe核实实际接口。`[opinion]`

```text
python -X utf8 install.py
```

缺少Python时，Agent先按官方方法准备uv，然后运行
`uv run --no-project --python 3.11 python -X utf8 install.py`。
目标目录可用 `--dest <目标Agent的skills目录>` 指定。`[opinion]`

安装器核对bundle-manifest.json哈希、合并并备份已有Skill，发布失败时回滚。
安装后的入口为 `reseam-uv/references/full-installation.md`，由Agent继续处理全部依赖。
GPU、系统操作或访问条件按该合同逐项记录实际状态。`[opinion]`

包内 `reseam-uv/assets/runtime-source.zip` 保存与当前工具匹配的执行源码，
`runtime-manifest.json` 以逐文件SHA-256及内容哈希标识实际版本。源码中的CLI采用所记录提交
的基线，排除无关workbench；其它执行模块捕获打包时的内容，不声称等于HEAD。
模型、权重、实验记录和本机runtime.local配置不随源码包分发。`[opinion]`

```text
python skills/reseam-uv/scripts/reseam_workflow.py --check
```

launcher先核对内容匹配的checkout，否则解包到独立用户缓存；不会覆盖已有checkout。
依赖检查不代表Blender／OptCuts实际运行或制作质量已通过。`[opinion]`
