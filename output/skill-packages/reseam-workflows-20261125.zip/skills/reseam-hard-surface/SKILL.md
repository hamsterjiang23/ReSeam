---
name: reseam-hard-surface
description: 在 ReSeam 中按硬边、尖刺和凹折规划 UV 切缝，控制拉伸后再复用纹理；适用于硬表面展开及与少岛布局的实际对照，不以岛最少为目标。
---

# 硬表面 UV 展开与复用

首次运行或后端依赖缺失时，先读同级主Skill的
`../reseam-uv/references/environment-setup.md`，由Agent按所选路径补齐环境并冒烟；
本专项与 `reseam-uv` 一同安装，不要求用户预先手动装好全部后端。

使用 ReSeam 的 JSON 工具接口。先运行 `uv run reseam tools list`，再查询
`tools describe <工具名>`；每个请求使用不可变父快照和从未存在的新输出目录：

```text
uv run reseam tools run <工具名> --request <绝对路径.json> --output <新目录>
```

## 决策依据

选择硬表面路线、局部合岛效果不佳或normal/AO线索与外观不一致时，先查主Skill的 [制作案例索引](../reseam-uv/examples/index.md)，按问题读取 [Chloe硬边与拉伸取舍](../reseam-uv/examples/chloe-hard-surface.md) 或 [Tripo匕首局部合岛](../reseam-uv/examples/tripo-spike-hard-surface.md)。记录借鉴的决策，重新确认当前原边、来源通道与质量要求。`[opinion]`

烘焙前用 `material.preflight` 交叉检查实际法线与 UV，并执行显式高模/Cage 投射诊断，详见仓库根相对路径 `docs/uv-normal-baking-workflow.md`。`mesh.hard_edges` 的候选过滤与预检目的不同：原多边形内部对角线上的真实法线不连续仍须报告。不要把“硬边需 UV 接缝”倒推为所有 UV 接缝都设硬边，也不按固定 1 像素验收所有 mip。`[verified: preflight.py normal_uv_audit、uv_sampling_audit；opinion: 使用规则]`

当前默认主线收敛为：**OptCuts 初始切缝 → Agent 审阅与局部改缝合岛 → 排布和烘焙验收**。
使用现有工具，不再为每种策略增加入口。先 `uv.baseline method=optcuts`，读取实际UV与原边接缝；
Agent结合模型、棋盘格、法线/AO线索，决定保留、删除或补充哪一段切缝。
合并只针对原边相邻的完整岛/自然区域：保存OptCuts其它开口，删除明确选中的共同边界，
通过 `uv.reparameterize` 重新展开该区域，再检查全模型岛数、拉伸与外观。不能只焊UV坐标或
把图块摆近就宣称合岛；OptCuts已很少岛时允许不合并。跨部件堆叠仍是独立复用步骤。
旧的按角度大量加缝路线保留作对照；本主线不默认叠加全部AO/normal候选边，也不追求最少岛。

保留尖端、棱线、凹槽与纹理方向，先控制明显拉伸，再考虑共享、覆盖和岛数。
共享是不同表面共用纹理；合岛是连续表面减少切缝，两者分别统计。不要强制把整件
硬表面变成一个圆形 UV 岛，也不要机械地把每个三角形拆开。

1. 导入并保存原 UV、材质及非活动 UV。FBX 可显式请求
   `asset.import collect_normal_evidence=true`，只增加逐角法线和 sharp 信息诊断，
   不代表已复现法线着色或原 Shader。
2. `mesh.hard_edges` 分别报告导入自定义法线不连续、导入 sharp 标记、几何二面角代理、
   三角化内部对角线。旧快照缺失法线时如实报告；可传 `source_snapshot` 提供同索引几何的
   新诊断导入，镜像资产只沿已存原面/重心对应追溯。不得按坐标接近补身份。
3. `view.render` 观察原色、法线几何视图、折角及背面。几何法线视图不代表源自定义法线。
   用 `region.define` 冻结自然部件及保护特征；用 `seam.select/preview` 确认实际原边。
   可用 `mesh.index ao_rays=16` 的几何AO和明确绑定的 AO、normal、height/displacement 图辅助选边：
   给 `mesh.hard_edges mesh_index=...` 或 `maps={ao|normal|height:{path,...}}`，读取逐边 cue。
   AO是凹槽/接触线索；normal比较需声明切线约定；高度图需声明通道，归一化差值不等于实际位移。
   缺图就标未绑定，不能把BaseColor明暗转换成真实AO/高度，也不因AO深色就强制切缝。
4. 把明显折角、凹槽、部件交界作为优先切口；尖锥可将部分侧面连成扇形/条带，
   留必要纵切。硬边为候选而非无条件全切；每项连接例外记录局部外观与拉伸理由。
   排除有可靠原多边形身份的三角化对角线；身份缺失时注明无法完成这项排除。
5. 先在一个相邻岛合并区域冒烟，再扩大。需要补缝时才按证据比较几何折角45°/30°/60°，
   这些是可选启发式，不是默认全模型切分。局部重展开先 LSCM，失败或明显拉伸时在同切口上
   尝试 minimum-stretch。参数和后端能力以当前工具为准，拒绝须保存。
6. `uv.reparameterize` 写回原面角 UV；共享区域先解除共享。向工具传完整自然区域和
   原顶点 ID 边对，保留未选区域。先获得无共享烘焙，再 `reuse.check_pair/apply` 尝试兼容
   部件共享，几何与外观不兼容时整块保留独占，不强迫镜像或改模。
7. `uv.pack → material.target → view.render` 预检原始/目标/差异，再
   `material.bake → quality.validate → asset.export`。改 UV 就重新烘焙；目标改变就重新预检。

## 比较与交付

默认只比较 OptCuts 无共享与 Agent 整理后的候选，真实合岛与跨部件堆叠分别计数。
旧的硬边无共享/共享、harmonic等路线仅在问题需要时追加，不默认把所有后端都跑一遍。
原始与镜像资产分别固定几何、源颜色目标、尺寸、留边、密度、种子、代码与预算。
原始既存交叠不算新增共享；任何颜色对称化须先说明并冻结目标，同目标提供无共享对照。

报告真实原色/棋盘格、UV、硬边/接缝叠图、拉伸热图、尖端和凹槽近景，并列逐面
拉伸中位数/P95/最大值、超限面、接缝长度、岛数、图块、有效共享面积及失败成本。
外观优先时数值阈值作为诊断，超限记录定位与判断，不修改旧数值结论。
导出模型重新载入核对几何、UV、嵌入贴图及额外 UV。

单工具默认300秒；任务未指定时每种几何2400秒，包含冒烟、失败、烘焙与报告。
同一假设最多修订三次，随后换机制或回退。数值通过、Agent外观、人工、PBR和GPU状态独立；
无通过结果可诊断导出并明确失败。静态 BaseColor 验收不能证明切线法线或原游戏材质正确。
