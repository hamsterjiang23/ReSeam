---
name: reseam-uv
description: 在 ReSeam 仓库通过 JSON CLI 分析静态网格，完成同模型 UV 共享、真实合岛、紧凑排布、烘焙、具名交付与制作／baseline对比图；支持已授权的镜像变体，不负责生成模型或自动认可艺术质量。
---

# ReSeam UV 复用

## 按需借鉴制作案例

需要选择制作路线、用户指定参考历史做法、遇到已有案例覆盖的症状，或对应/展开/合岛/烘焙反复失败时，先查 [制作案例索引](examples/index.md)，再读匹配的案例。索引覆盖原UV保留、选区外碎片、镜像细线岛、白爪错贴、PBR投射黑线及硬表面合岛等问题。直接查询参数时按当前 `tools describe` 操作。案例按问题加载。`[opinion]`

借鉴后在当前任务记录中简要写明案例、匹配依据、采用的决策和资产差异。历史事实沿案例所列仓库根相对路径查证，源码仓库定位沿用 [环境预检](references/environment-setup.md)。重新取得当前面/边ID、状态哈希、对称平面、材质来源、参数和验收要求。镜像改模依据当前资产授权，历史质量结论按其原范围保留。`[opinion]`

## 可复用制作工具

逐部件重展开、小样制作、具名多对象交付或历史／baseline对比出图时，读取 [工作流工具](references/workflows.md)，通过 [统一入口](scripts/reseam_workflow.py) 调用 `rebuild`、`preview`、`collect`、`report`。最小请求见 [rebuild](requests/rebuild.json)、[preview准备](requests/preview-prepare.json)、[preview烘焙](requests/preview-bake.json)、[collect](requests/collect.json)、[report](requests/report.json)，辅助工具清单见 [tools.json](scripts/tools.json)。这些入口编排现有JSON工具；部件清理与镜像仍按当前资产授权，工具执行不自动认可外观。`[opinion]`

`preview` 先准备冻结目标和差异图，由Agent实际看图记录后再烘焙；`report` 读取已有结果，只有显式请求才补渲染。安装包中的源码快照按内容哈希匹配，环境缺失按 [全量安装合同](references/full-installation.md) 处理。`[opinion]`

## 美术操作与目视保留

用户要求美术局部修整、稳定试做或肉眼验收时，使用仓库 `docs/artist-tools.md` 的 `artist.*` 入口。`artist.select/protect/compare/checkpoint/trials/relax/groups/preview` 覆盖定位、保护、对照、回退和实际导出渲染。每项参数仍查 `tools describe`。

本轮用户已选择目视外观判断，新的美术路径用 `acceptance_policy=visual`，或由美术编辑产生的快照继承该模式。重新展开/排布/颜色目标/烘焙的数值证据仅参考，实际看图后调用 `artist.review`，再用 `artist.export` 形成目视交付。不要调用严格数字门禁代替这次用户授权的外观判断，也不要把目视通过写成数值通过。选区、固定点、状态哈希、文件完整性、零面积和保护冲突仍保留基本检查。

查看实际准备的前后角度再记录意见，`reviewer=agent` 不能写成 `human`。模型已经没有的法线等通道不补造。`artist.preview` 用 Blender 读入实际 GLB，不代表 Unity 或用户 GPU 验收。工作台按钮输出可复制的请求 JSON，由 CLI/Agent 执行。

## 首次使用与依赖缺失

用户要求“一键安装”“全量安装”或安装全部依赖与工具时，读取 [全量安装合同](references/full-installation.md) 和 [依赖清单](references/install-manifest.json)，按清单逐项准备全部后端、合并本机配置并实际冒烟。该请求采用全量模式，Agent持续处理可完成的项目，并记录每项可用性及具体阻碍。`[opinion]`

首次到一台机器、找不到 `reseam` 命令、运行时配置缺失或后端启动失败时，先读
[环境预检与按需安装](references/environment-setup.md)，由当前Agent定位仓库、检查并安装
所选路径缺少的依赖，配置本机运行时，再做小型冒烟后继续用户任务。
普通本地依赖安装在任务授权范围内时直接执行，不把整份安装清单交回用户；需要仓库地址、
管理员权限、重启或受限权重访问时，只请求实际缺少的那一项。不要默认安装全部研究后端，
也不要因 `doctor` 的无关可选依赖为false就中止可运行路径。

在 ReSeam 仓库运行 `uv run reseam tools list`，随后对需要的操作运行
`uv run reseam tools describe <工具名>`。参数以当前 CLI 说明为准。此 Skill 的 LLM 就是调用工具的 Agent，无需另接模型 API。

每次调用写一份 JSON 请求，再运行：

```text
uv run reseam tools run <工具名> --request <request.json> --output <从未存在的新目录>
```

文件引用使用绝对路径。标准输出是结果 JSON；读取输出目录的 `result.json`、`process.log` 及返回的证据文件。默认每项操作 300 秒，可在请求中设置 `timeout_seconds`。不另写几何或烘焙辅助脚本绕过工具门禁。

## 执行路线

用户要求按part整理UV时，先读 [分割部件流程](references/segmented-parts.md)，用 `asset.prepare_parts` 保留身份与来源，逐部件重建必要切口、真实合岛并清理小片，再选择镜像／共享及统一图集。不能只识别部件、保留旧UV或做堆叠就宣称完成。小片优先按原边归位／合岛，删除须在新变体中看真实前后图；真实细节片不能因UV小而盲删。先512小样，再做同几何共享／无共享对照。`[opinion]`

准备法线烘焙或解释硬边/UV问题时，先读仓库根相对路径 `docs/uv-normal-baking-workflow.md`，调用 `material.preflight`。分别读取源法线与实际导出目标法线、UV采样和投射状态；`pass/warn/fail/not_checked` 不授权自动改模或验收。显式提供实际分辨率/留边/mip；缺高模不补造射线命中。当前平面目标法线可能与光滑源模型不同，先解释差异再决定现有工具的修正动作。`[verified: preflight.py preflight、normal_uv_audit；opinion: 调用顺序]`

用户只需给模型和外观/复用目标，由Agent选择已有工具，不要求用户逐个挑后端。
需要重新规划切缝时，默认收敛为 **OptCuts 初始切缝 → Agent 局部合岛/兼容区域复用 → 排布与烘焙验收**；
原UV可用且要求保留时继续保留。AO、normal和其它后端按已定位问题调用，不默认全跑。

硬表面、尖刺、明显折角或凹槽需要控制拉伸时，使用同级 `reseam-hard-surface/SKILL.md`；
按硬边规划切缝，先无共享展开和烘焙，再研究复用，不以连通岛最少作为目标。

用户要求对称部件复用、整半共享、复用后减少连通岛或紧凑排布时，先读
[对称复用与真实合岛 workflow](references/symmetry-reuse-and-merge.md)。默认保持当前资产几何；
仅在该资产已有明确授权时创建镜像新变体。旧龙模型的授权不适用于新资产。
先测实际共享，再处理同一连通表面内部的多余接缝；不要把堆叠当作真正合岛。`[opinion]`

UV出现孤立细线或近乎空白的图块时，先走专项workflow的“细线岛诊断与中线修复”。
读取 `midplane_review_required` 及报告候选，区分真实薄表面、裁切残条与UV压扁；
修正平面仅用于当前资产已授权的新变体，不复制旧龙的具体偏移值。`[opinion]`

需要按语义重构接缝、减少旧岛碎片时，先读 [网格查询与接缝计划](references/meshquery.md)。
使用 `mesh.index/query` 观察，`region.propose` 提供候选，Agent 看图命名后调用 `region.define`。
用 `seam.select/preview` 确认真实边，再 `seam.submit_plan/apply` 展开；参数以 `tools describe` 为准。
多视图、SQL 数值和部件标签共同支持决策，标签或对称切缝本身不是共享许可。

保留原UV可用区域，只对已声明区域改接缝。薄翼膜正反面分别观察，翼骨和四肢优先背面纵切，
角刺保留根到尖的连续走向；眼嘴、爪子明显颜色边界列为保护区。
三角网格不猜四边形边环，改用原边路径、区域边界和折痕算子。先无共享展开与烘焙，
再比较成对共享。单个计划失败回到父快照，整块修改路径或锚点，不自动隔离大量三角面。

主流程由当前 Agent 提供通用预训练 VLM 判断，不训练或微调模型。PartField 是独立研究分区路径，
其许可、权重和运行成本单列；不因研究依赖缺失切换主流程算法或伪造论文复现。
每个重工具默认300秒，每条真实路径总预算2400秒；保留同一假设最多三次修订及全部失败。
报告区分工具实现、实际改进、Agent外观评价、人工认可；工业可用性和泛化仍需额外证据。

1. `asset.import` 冻结原始输入。GLB 是完整材质路径；OBJ 用独立 `reference` GLB 供应真实材质。输入无 UV 时显式设置 `initialize_uv: "xatlas"`。不替换用户输入或历史试验资产。
2. `uv.inspect` 查看编号岛、畸变和重叠；`view.render` 查看真实颜色、棋盘格、编号岛、接缝或错误面。需要定位时传入 `pick_pixels` 取得原面 ID 与重心坐标，再用 `selected_faces` 或 `region_id` 查看局部。诊断视图不替代质量渲染。
3. 先用 `uv.pack`、`material.bake`、`quality.validate` 建立无共享基线。记录全部配置、分辨率、阈值和耗时。基线不通过时报告失败区域，先排查投射、拓扑、UV 或材料支持问题。
4. `reuse.find_candidates` 给出候选；结合模型图和材质，用 `region.define` 保存语义区域、保护面及证据。区域可跨旧岛，不按坐标接近焊接。保存包含原面 ID、理由、例外面和父状态哈希的提案；`reuse.check_pair` 检查对应及最终 UV，拒绝不等于数学上无法复用。
5. 对通过的提案用 `reuse.apply` 建新快照，必要时 `uv.pack`。同组保持共同映射；差异区通过整面独占处理。`exclusive` / `unshare` 用于回退局部关系。固定几何路线不强制镜像；明确授权的新变体按专项 workflow 执行。
6. 对新快照重新 `material.bake`、`quality.validate`；旧贴图或旧验收不能用于改过 UV 的状态。比较完整实际通道和 mip，不以岛少、填充率或 BaseColor 预览代替质量验收。
7. `asset.export` 导出已验收结果。没有通过结果时可用明确的 `mode: "diagnostic"` 导出失败证据，并保留最好已通过快照。最终报告链接真实贴图、原始/修改 UV、渲染、最低已验收字节数及所有拒绝/超时成本。工具完成、节省存储、艺术验收分别报告。

默认 `material.target` / `basecolor_reuse` 要求源材质与导入网格有相同面角身份；
不同高低模须显式使用 `source_mode=projected_high`，参见[投射来源与多UV](references/projected-source-and-extra-uv.md)。
同页说明FBX显式颜色/UV绑定、原UVIndex恢复和第二UV导出；先检查来源与通道，再开展共享。
`basecolor_diagnostic` 只返回颜色报告、真实贴图和预览 GLB，不产生可传入 `quality.validate` / `asset.export` 的 `bake.json`。
其结果可独立重新导入检查，但不能升级成正式材质验收；需要这两个接口时使用支持的 PBR 或同身份颜色路径。
观察模型时读取返回的坐标约定：固定镜头下某一视角为空可能是开放薄片侧视，继续检查其它视角。

## 整龙迭代与颜色范围

本轮 tripo_p2 的执行合同在仓库 `docs/dragon-llm-reuse-plan.md`，完整参数以 `tools describe` 为准；接口列出不代表后端冒烟或整龙验收已通过。

- 按脚与腿、翼膜与翼骨、重复角刺推进。头脸和明显特征默认保护。先取得部件级共享，再扩展整龙；同一假设连续三次失败后，依据错误面更换对应、区域或展开方法。
- 本轮优先实际UV复用。独立图块、实际交叠覆盖面积和烘焙质量是主要结果；编码压缩留作可选诊断。共享组成员面积不等于实际交叠面积，排布owner数也不等于实际交叠连通图块数。
- 语义区域跨多个旧岛时，可检查 `chart_aware` 对应：按主UV图分组并重建目标切缝。需修复时显式保留带拒绝标记的诊断快照；不能直接当作已通过结果。固定映射后释放冲突面，优先提出连贯的整面例外，再用 `exclusive_layout=preserve_patches` 保留片内UV，避免删除主面后重新投影产生孔洞塌缩。
- 排布把原零面积接触变成新正面积冲突时，可显式启用 `repair_packing_roundoff`。该选项改变受限的实际UV坐标并重新执行完整门禁；它不提供面积豁免。读取操作记录中的修正次数、节点变化和拒绝原因，实际未执行修正时不归因于它。
- `uv.reparameterize` 显式选择区域及几何后端。本轮允许 OptCuts 作为实验展开后端；先核验面角映射、原几何不变和运行版本。它不替代跨部件对应，也不改变历史自研求解器的范围。
- 仅在用户允许对称化修饰时，选择主纹理成员并用 `material.target` 冻结源贴图及固定对应构成的目标；保护区保持原信号。目标不能由待验收贴图反向生成，外观修改量与重建误差分别报告。
- `material.bake mode=basecolor_reuse` 使用明确的颜色目标，再调用独立验收与导出。其通过只代表报告声明的 UV＋BaseColor 范围，不能变成完整 PBR、GPU 或艺术通过。`basecolor_diagnostic` 仍保持仅诊断身份。
- 冻结对称化目标后，为它单独运行无共享对照。新龙协议验证 LOD 0、1、2；完整 mip 写出不代表其余层通过。纹理尺寸枚举不假定成功单调。
- 对从 FBX 属性拆点导出的模型，给 `material.target` 提供可追溯的 `original_topology`，恢复原始面角邻接的接缝检查；没有该证据时只报告输入网格范围，不能按坐标焊接来补身份。
- 追求更小贴图时，可通过 `uv.pack face_density_scale` 对错误集中部位做一次完整 owner 的密度调整，随后恢复密度约束并重新验收；普通后续排布不重复施加。公共调整向全部 Baseline 提供，单独保存同父状态消融。
- 需要编码诊断时才调用 `material.encode`，随后重新验收；参数查工具说明。它不代替UV复用比较，也不自动代表目标GPU已验证。

## 对称复用、真实合岛与紧凑排布

具体输入、工具衔接、请求示例、切口修正、缩图限制和交付表格统一放在
[专项 workflow](references/symmetry-reuse-and-merge.md)，按当前任务读取相应步骤。
镜像产生新父几何；堆叠减少独立图块；重展开可能减少连通岛；排布改善覆盖；缩图才改变纹理尺寸。
这些收益分别比较。保留最好已验收状态和外观预览状态，数值拒绝的预览不能覆盖已验收结果。`[opinion]`

## Baseline 与步骤证据

用户要求保留原始可用UV时，不先运行 `reuse.apply action=exclusive` 隔离异常面。可显式设置 `profile.preserve_source_uv={snapshot,state_hash}`，同一策略通过 `geometry_profile` 绑定目标、烘焙和验收。它仅容忍指定源快照已存在、局部布局保持共同旋转/缩放/平移的交叠或接触；不新增岛，严格检查失败另行保留。新冲突仍拒绝，原有小交叠不计入共享面积或新增堆叠收益。没有该字段时维持严格行为。

`material.target` 后使用 `reuse.check_color` 设置 `level=low|medium|high`（默认中），也可传入正数 `radius`。它比较源颜色与冻结共享目标的Oklab球形距离，同时输出三档统计和 `exceedance_faces`；半径单位与预设以 `tools describe` 为准。球内满足容忍度；球外区域看图判断，保留越界证据，不因少量点自动挖出碎片。仅全部采样球内才记录 `color_accepted=true`。颜色球检查、源/目标视觉判断及候选烘焙重建验收各自记录，不相互冒充。

部件重展开使用 `region.define seed_faces+boundary_edges` 或显式面集合，`uv.reparameterize seam_edges` 删除旧内部碎片并建立新切口；边使用原顶点ID对。计算时临时提取，最终仅写回原模型UV。OptCuts可能增加切口，读取 `result_seam_edges` 后传给下一步。

OptCuts可能直接信任单岛旧UV而遗漏全局交叠；明确重做部件时可设置 `initial_uv=geometry`，只将指定切口后的部件几何传给后端计算新初值。未选区域原UV保留，不通过先把原面拆成独立三角岛来初始化。默认 `existing` 保留旧行为；读取实际后端与拒绝证据。

`reuse.check_pair mode=paired_domain` 接收成对区域、两侧切口和至少三个 `boundary_anchors`。锚点用 `{first:[原面ID,面角],second:[原面ID,面角]}` 指定切口侧，按对应边界弧段组织。`domain=master_uv` 尝试主侧当前布局；允许的凸域回退明确记录。未配对边界采样仍可能造成覆盖不足，须读实际交叠覆盖，不能假定共享率100%。失败优先调整锚点、切口、自然分区；整个特征片可保留独占。

颜色目标预检先用 `material.target` 冻结，再 `view.render mode=basecolor,target=...` 查看原始、目标及差异。记录Agent判断后才烘焙；`view.render texture=...` 才是实际烘焙贴图预览。`uv.inspect selected_faces/region_id` 返回所选区域实际共享面积；全局真实图块数不因选择缩小。外观优先的显式 `geometry_profile` 绑定目标、烘焙与验收，与旧严格协议分开记录。

整龙实验必须比较无共享必要修复、OptCuts 无共享修复、纯几何复用、Agent 迭代复用。受控比较使用相同父资产、预处理、候选池、UV 起点、目标外观、后端、质量与执行预算；不同提案来源的端到端比较单列。失败、超时、未运行都保留，不只输出最好结果。

每次区域定义、对应修正、接缝重构、展开、共享、对称化、排布及缩图，保存父子快照哈希、同视角图、相同口径的指标与差值、理由、工具输入、耗时、失败面和接受结论。消融从同一个父状态出发，只改变研究变量。代码修正若影响 Baseline 或验收，新建冻结轮次并重跑受影响路径，不与旧代码结果混排。

分别报告 UV 连通岛数、独立图块数、共享组及面积、纹素密度、颜色误差、完整 mip 字节和包体。堆叠后的两个连通岛不能误记成一个岛；单对部件或零散三角形成功不能代表整龙完成。

## 失败反馈

- `REJECTED`：读原因和失败面；缩小共享区域、改对应或释放整面例外，再从父快照重新检查。不要调宽阈值后宣称原协议通过。
- `DEPENDENCY_MISSING`：仅安装或配置所需后端；不能悄悄换算法冒充成功。分析不依赖 Blender。
- `TIMEOUT` / `ERROR`：保留日志与已完成证据；重新调用使用新目录。父状态保持不变，失败子产物不参与最优结果比较。
- 参数或父哈希过期：从当前快照重新生成检查提案。
- xatlas 对极小面输出退化 UV：可显式重新导入并设置 `repair_degenerate_faces: true`，将这些原始面隔离为内禀等距三角岛，再 `uv.pack`；检查返回的修复面清单，几何与面数不变。
- 默认支持静态、不透明标准 PBR；额外 Shader、动画、混合/多材质等支持由工具明确判定。不得用伪造贴图补齐不支持的功能。
- 遇到材质扩展不支持但仍需研究颜色/UV，可明确请求 `material.bake` 的 `mode: "basecolor_diagnostic"`；返回颜色贴图与专用预览，永不标为完整材质验收通过，不能输入 accepted 导出流程。

在相同质量条件下比较无共享、纯几何选择与 Agent 选择。预算是有限枚举，不假设求解成功对尺寸单调。
只有按声明范围实际通过的候选才标为已验收结果；数值拒绝但Agent外观接受的候选可另存为有限视角外观预览、诊断导出。
人工艺术认可单列，新资产的LOD与质量设置显式冻结，不自动继承历史龙模型协议。`[opinion]`
